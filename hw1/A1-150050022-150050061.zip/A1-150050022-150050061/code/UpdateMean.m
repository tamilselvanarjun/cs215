function val = UpdateMean(oldMean,z,A,n),
	val = (n*oldMean + z)/(n+1);
end
